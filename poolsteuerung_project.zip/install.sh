#!/bin/bash
echo 'Installiere...'
